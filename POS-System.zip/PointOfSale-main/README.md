<h1>Point of Sale on PHP</h1>
<h5>The intention of this project is to create simple web-based Point of Sale system using PHP. 
The expected ouput of this project are:</h5>
<ul>
<li>Login system</li>
<li>Can create users</li>
<li>Can Create customers</li>
<li>Can add products</li>
<li>Can delete products</li>
<li>Can add sales</li>
<li>Records delivery</li>
<li>Records Cashin/Cashout</li>
<li>Can View Logs</li>
<li>Inventory</li>
<li>And other addition in the future.</li>
</ul>
<h5>This project is still in progress.</h5>
